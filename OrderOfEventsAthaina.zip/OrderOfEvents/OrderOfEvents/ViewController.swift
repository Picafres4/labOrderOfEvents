//
//  ViewController.swift
//  OrderOfEvents
//
//  
//
import Swift
import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        print("ViewController - View Did Load")
    }
    

    

}

